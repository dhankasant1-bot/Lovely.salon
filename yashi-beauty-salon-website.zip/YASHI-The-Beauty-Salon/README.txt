YASHI's The Beauty Salon website

READY-TO-HOST WEBSITE
The ready-to-host folder contains the production website. Upload the contents of that folder (including index.html, assets, images, and favicon) to a static website host.

SOURCE FILES
The source folder contains the editable React/Vite project files. The source package was built within Replit's pnpm workspace; the ready-to-host folder is the portable static website.

APPOINTMENTS
The form prepares a text message to 09329693991. The visitor must send the message, and the salon must confirm the appointment. This site does not store or automatically submit booking requests.

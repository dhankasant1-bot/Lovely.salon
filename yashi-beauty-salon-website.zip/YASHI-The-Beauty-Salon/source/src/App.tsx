import { type FormEvent, type ReactNode, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { ArrowDown, ArrowRight, ArrowUpRight, CalendarDays, ChevronDown, MapPin, Menu, Phone, Sparkles, Star, X } from 'lucide-react';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';

const queryClient = new QueryClient();

function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [smsReady, setSmsReady] = useState(false);
  const [selectedService, setSelectedService] = useState('');
  const address = 'House No. 1, Gufa Mandir Rd, Jain Nagar, Nayapura, Lalghati, Bhopal, Madhya Pradesh 462030';
  const mapUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address)}`;
  const services = ['Haircut & Styling', 'Hair Spa', 'Hair Coloring', 'Facial', 'Cleanup', 'Makeup', 'Bridal Makeup', 'Manicure & Pedicure', 'Waxing', 'Threading', 'Skin Care'];
  const nav = [['Home', '#home'], ['About', '#about'], ['Services', '#services'], ['Gallery', '#gallery'], ['Reviews', '#reviews'], ['Contact', '#contact']];
  const submitBooking = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const body = [
      'Hello YASHI\'s The Beauty Salon, I would like to enquire about an appointment.',
      `Name: ${data.get('name')}`,
      `Phone Number: ${data.get('phone')}`,
      `Service: ${data.get('service')}`,
      `Preferred Date: ${data.get('date') || 'Not specified'}`,
      `Preferred Time: ${data.get('time') || 'Not specified'}`,
      `Message: ${data.get('message') || '—'}`,
    ].join('\n');
    setSmsReady(true);
    window.location.href = `sms:09329693991?body=${encodeURIComponent(body)}`;
  };
  return (
    <div className="site-shell min-h-[100dvh]">
      <a href="#main" className="sr-only focus:not-sr-only focus:fixed focus:z-[100] focus:top-3 focus:left-3 focus:bg-white focus:px-4 focus:py-2">Skip to content</a>
      <div className="topline hidden sm:flex items-center justify-center gap-7 py-2.5">
        <span>BHOPAL · LALGHATI</span><Star aria-hidden="true" size={10} className="fill-[#c9ae73] text-[#c9ae73]" /><span>BEAUTY, STYLE & CONFIDENCE — ALL IN ONE PLACE</span>
      </div>
      <header className="sticky top-0 z-50 border-b border-[#eadfe0] bg-[#fbf8f5]/95 backdrop-blur-md">
        <div className="mx-auto flex h-[76px] max-w-[1320px] items-center justify-between px-5 md:px-10">
          <a href="#home" className="group flex items-center gap-3" aria-label="YASHI's The Beauty Salon home">
            <span className="flex h-11 w-11 items-center justify-center rounded-full border border-[#b79a5b] text-[#532d3a]"><span className="serif text-xl italic">Y</span></span>
            <span className="leading-tight"><span className="serif block text-[18px] font-semibold tracking-wide text-[#33272d]">YASHI'S</span><span className="block text-[9px] tracking-[.24em] text-[#7f6d72]">THE BEAUTY SALON</span></span>
          </a>
          <nav className="hidden items-center gap-8 lg:flex" aria-label="Main navigation">
            {nav.map(([label, href]) => <a key={label} className="nav-link text-[12px] font-semibold tracking-[.11em] text-[#55484d] hover:text-[#532d3a]" href={href}>{label}</a>)}
          </nav>
          <div className="hidden items-center gap-5 lg:flex">
            <a className="flex items-center gap-2 text-[12px] font-semibold text-[#532d3a]" href="tel:09329693991"><Phone size={14} /> 09329693991</a>
            <a href="#appointment" className="btn-primary inline-flex items-center gap-2 px-5 py-3 text-[10px] font-bold tracking-[.16em]">BOOK A VISIT <ArrowRight size={14} /></a>
          </div>
          <button className="flex h-11 w-11 items-center justify-center text-[#532d3a] lg:hidden" onClick={() => setMenuOpen(!menuOpen)} aria-label={menuOpen ? 'Close navigation menu' : 'Open navigation menu'} aria-expanded={menuOpen}>
            {menuOpen ? <X /> : <Menu />}
          </button>
        </div>
        {menuOpen && <nav className="menu-panel border-t border-[#eadfe0] bg-[#fbf8f5] px-6 py-4 lg:hidden" aria-label="Mobile navigation">
          {nav.map(([label, href]) => <a key={label} onClick={() => setMenuOpen(false)} className="block border-b border-[#eee4e5] py-3 text-sm tracking-wide" href={href}>{label}</a>)}
          <a href="#appointment" onClick={() => setMenuOpen(false)} className="btn-primary mt-4 flex items-center justify-center gap-2 py-3 text-xs font-bold tracking-widest">BOOK A VISIT <ArrowRight size={14} /></a>
        </nav>}
      </header>
      <main id="main">
        <section id="home" className="relative isolate overflow-hidden bg-[#f3e9e8]">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_8%_18%,#fff9f1_0%,transparent_37%),linear-gradient(110deg,#f4e8e7_0%,#f3e8e7_46%,#e7d6d6_100%)]" />
          <div className="relative mx-auto grid min-h-[640px] max-w-[1440px] grid-cols-1 items-center px-5 py-12 sm:px-10 md:min-h-[690px] md:grid-cols-[1fr_.9fr] md:py-16 lg:px-20">
            <div className="z-10 max-w-[610px] py-8 md:py-10">
              <p className="eyebrow mb-6 flex items-center gap-3"><span className="h-px w-9 bg-[#b79a5b]" /> YOUR BEAUTY, YOUR WAY</p>
              <h1 className="serif text-[clamp(3rem,6.1vw,5.5rem)] leading-[.97] tracking-[-.05em] text-[#382a30]"><span className="block">YASHI's</span><span className="block">The Beauty</span><em className="block font-medium text-[#9a6978]">Salon</em></h1>
              <p className="mt-7 max-w-[430px] text-[15px] leading-7 text-[#66585d] sm:text-[17px]">Beauty, Style & Confidence — All in One Place</p>
              <p className="mt-3 max-w-[410px] text-[13px] leading-6 text-[#75676b]">A welcoming Lalghati salon for the rituals, refreshes and moments that help you feel your best.</p>
              <div className="mt-9 flex flex-wrap items-center gap-3">
                <a href="#appointment" className="btn-primary inline-flex items-center gap-3 px-6 py-4 text-[10px] font-bold tracking-[.16em]">BOOK AN APPOINTMENT <ArrowRight size={15} /></a>
                <a href="tel:09329693991" className="btn-outline inline-flex items-center gap-3 px-6 py-4 text-[10px] font-bold tracking-[.16em]"><Phone size={14} /> CALL NOW</a>
              </div>
              <div className="mt-10 flex items-center gap-3 border-t border-[#cdbabc] pt-5">
                <div className="flex gap-1 text-[#b3924f]" aria-label="5 out of 5 stars">{[1,2,3,4,5].map(n => <Star key={n} size={13} fill="currentColor" strokeWidth={1} />)}</div>
                <span className="text-sm font-semibold text-[#44363b]">4.9/5</span><span className="text-xs text-[#76696d]">from 1,032 reviews</span>
              </div>
            </div>
            <div className="hero-art relative mx-auto mt-8 h-[390px] w-full max-w-[590px] md:mt-0 md:h-[570px]">
              <div className="absolute right-[5%] top-[4%] h-[91%] w-[78%] overflow-hidden rounded-t-[48%] rounded-b-[3px] border-[9px] border-[#fbf6f2] shadow-[0_24px_55px_rgba(77,44,55,.16)]">
                <img src="/yashi-editorial.jpg" alt="Editorial portrait representing the beauty and styling experience at YASHI's salon" className="h-full w-full object-cover object-[57%_center]" />
              </div>
              <div className="absolute bottom-[8%] left-0 flex h-[114px] w-[114px] flex-col items-center justify-center rounded-full border border-[#b79a5b] bg-[#fbf8f5] text-center shadow-lg">
                <span className="serif text-3xl text-[#532d3a]">Y</span><span className="mt-1 text-[8px] tracking-[.19em] text-[#806c72]">BEAUTY<br />IN YOUR ELEMENT</span>
              </div>
              <div className="absolute right-0 top-[18%] hidden -rotate-90 text-[9px] tracking-[.28em] text-[#8c7379] sm:block">FEEL GOOD. LOOK LIKE YOU.</div>
              <span className="absolute right-[0%] bottom-[11%] flex h-12 w-12 items-center justify-center rounded-full bg-[#532d3a] text-[#f8e9e9]"><Sparkles size={18} /></span>
            </div>
          </div>
          <a href="#about" className="absolute bottom-5 left-1/2 hidden -translate-x-1/2 items-center gap-2 text-[9px] tracking-[.2em] text-[#8c7379] md:flex">SCROLL TO DISCOVER <ArrowDown size={13} /></a>
        </section>

        <section id="about" className="bg-[#fbf8f5] px-5 py-20 sm:px-10 md:py-28">
          <div className="mx-auto grid max-w-[1180px] items-center gap-12 md:grid-cols-[.94fr_1.06fr] md:gap-20">
            <div className="relative max-w-[480px]">
              <div className="absolute -left-4 -top-4 h-full w-full border border-[#c6ad78] sm:-left-6 sm:-top-6" />
              <img className="relative aspect-[4/4.5] w-full object-cover" src="/salon-stilllife.jpg" alt="Beauty tools and soft floral details in a salon setting" />
              <div className="absolute -bottom-5 -right-3 bg-[#532d3a] px-5 py-4 text-[#fff8f2] sm:-right-6 sm:px-7">
                <span className="serif block text-2xl italic">Your moment.</span><span className="mt-1 block text-[8px] tracking-[.2em] text-[#ddc7bd]">YOUR BEAUTY ROUTINE, REIMAGINED</span>
              </div>
            </div>
            <div className="md:pl-3">
              <p className="eyebrow mb-5">A PLACE TO FEEL LIKE YOURSELF</p>
              <h2 className="serif max-w-[560px] text-[clamp(2.6rem,5vw,4.2rem)] leading-[1.08] tracking-[-.04em] text-[#382a30]">Beauty is personal.<br /><em className="text-[#9a6978]">Your salon should be, too.</em></h2>
              <p className="mt-7 max-w-[530px] text-[14px] leading-7 text-[#6f6166]">YASHI's The Beauty Salon provides professional beauty and styling services in Bhopal from its location in Lalghati. Come in for a considered refresh, a little care, or the finishing touch for a meaningful day.</p>
              <p className="mt-4 max-w-[530px] text-[14px] leading-7 text-[#6f6166]">From hair and skin services to makeup, hands and feet, find the right ritual for you in one welcoming place. Tell us what you have in mind and we’ll help you take it from there.</p>
              <a href="#services" className="mt-8 inline-flex items-center gap-3 border-b border-[#b79a5b] pb-2 text-[10px] font-bold tracking-[.17em] text-[#532d3a]">MEET YOUR NEXT FAVOURITE SERVICE <ArrowRight size={14} /></a>
            </div>
          </div>
        </section>

        <section id="services" className="bg-[#f2e6e7] px-5 py-20 sm:px-10 md:py-28">
          <div className="mx-auto max-w-[1180px]">
            <div className="flex flex-col justify-between gap-5 md:flex-row md:items-end">
              <div><p className="eyebrow mb-4">THE SERVICE EDIT</p><h2 className="serif text-[clamp(2.8rem,5vw,4.5rem)] leading-none tracking-[-.04em] text-[#382a30]">A ritual for every<br className="hidden sm:block" /> version of you.</h2></div>
              <p className="max-w-[330px] text-[13px] leading-6 text-[#75676b]">Explore our salon services. For service details and current pricing, please get in touch.</p>
            </div>
            <div className="mt-12 grid gap-x-14 md:grid-cols-2">
              {services.map((service, i) => <a key={service} href="#appointment" onClick={() => setSelectedService(service)} className="service-row group flex min-h-[76px] items-center justify-between border-b border-[#cdbabc] px-1">
                <span className="flex items-center gap-4"><span className="serif text-[12px] italic text-[#ad8a70]">0{i + 1}</span><span className="serif text-[20px] sm:text-[23px]">{service}</span></span><ArrowUpRight size={17} className="text-[#8b7479] transition-transform group-hover:-translate-y-1 group-hover:translate-x-1" />
              </a>)}
            </div>
            <p className="mt-7 text-[11px] text-[#796a6f]">All services · Contact for Price</p>
          </div>
        </section>

        <section className="relative overflow-hidden bg-[#33242b] px-5 py-20 text-[#fbf6f0] sm:px-10 md:py-24">
          <div className="absolute -right-28 -top-36 h-[450px] w-[450px] rounded-full border border-[#76604c]/45" /><div className="absolute -right-14 -top-20 h-[330px] w-[330px] rounded-full border border-[#76604c]/45" />
          <div className="relative mx-auto max-w-[1180px]">
            <p className="eyebrow mb-5 text-[#d0b873]">THE YASHI'S DIFFERENCE</p><h2 className="serif max-w-[700px] text-[clamp(2.8rem,6vw,5rem)] leading-[1.02] tracking-[-.04em]">A good visit is about<br /><em className="text-[#d8b9bc]">more than the mirror.</em></h2>
            <div className="mt-14 grid gap-9 sm:grid-cols-2 lg:grid-cols-4">
              {[
                ['01', '4.9-star customer rating', 'A 4.9 out of 5 rating, based on 1,032 customer reviews.'],
                ['02', 'Professional service', 'Beauty and styling services for the look and care you have in mind.'],
                ['03', 'Friendly, thoughtful care', 'A welcoming salon experience with friendly staff.'],
                ['04', 'Clean, comfortable & convenient', 'Visit us in Lalghati, Bhopal, at the address below.'],
              ].map(([n, title, text]) => <div key={n} className="border-t border-[#786570] pt-5"><span className="serif text-sm italic text-[#c3a970]">{n}</span><h3 className="serif mt-5 text-[24px]">{title}</h3><p className="mt-3 text-[12px] leading-6 text-[#d0c3c3]">{text}</p></div>)}
            </div>
          </div>
        </section>

        <section id="reviews" className="bg-[#fbf8f5] px-5 py-20 sm:px-10 md:py-24">
          <div className="mx-auto max-w-[1020px] border-y border-[#d9c9c8] py-12 text-center md:py-16">
            <p className="eyebrow">LOVED BY OUR COMMUNITY</p>
            <div className="mt-6 flex justify-center gap-2 text-[#b3924f]" aria-label="Five stars">{[1,2,3,4,5].map(n => <Star key={n} size={18} fill="currentColor" strokeWidth={1} />)}</div>
            <p className="serif mt-4 text-[clamp(3rem,7vw,5.8rem)] leading-none text-[#532d3a]">4.9<span className="text-[.52em]">/5</span></p>
            <p className="mt-4 text-[13px] tracking-[.08em] text-[#6f6166]">A community rating from <strong className="font-semibold text-[#382a30]">1,032 reviews</strong></p>
            <p className="mx-auto mt-4 max-w-[430px] text-[12px] leading-6 text-[#89797e]">A little appreciation goes a long way. Thank you for choosing a local Bhopal salon.</p>
          </div>
        </section>

        <section id="gallery" className="bg-[#f5eded] px-5 py-20 sm:px-10 md:py-24">
          <div className="mx-auto max-w-[1320px]">
            <div className="mb-10 flex items-end justify-between gap-6"><div><p className="eyebrow mb-4">A GLIMPSE OF THE FEELING</p><h2 className="serif text-[clamp(2.8rem,5vw,4.5rem)] leading-none text-[#382a30]">The beauty of a moment.</h2></div><p className="hidden max-w-[260px] text-xs leading-6 text-[#796a6f] sm:block">Placeholder imagery—salon and service photographs can be added here.</p></div>
            <div className="grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-5">
              <figure className="gallery-card col-span-2 row-span-2 overflow-hidden bg-[#e8d7d7]"><img className="gallery-img h-full min-h-[320px] w-full object-cover md:min-h-[490px]" src="/yashi-editorial.jpg" alt="Beauty editorial placeholder portrait" /><figcaption className="sr-only">Portrait representing beauty and confidence</figcaption></figure>
              <figure className="gallery-card overflow-hidden bg-[#e8d7d7]"><img className="gallery-img aspect-[1/1.07] w-full object-cover" src="/salon-stilllife.jpg" alt="Styling and beauty tools placeholder" /></figure>
              <figure className="gallery-card overflow-hidden bg-[#e8d7d7]"><img className="gallery-img aspect-[1/1.07] w-full object-cover object-[30%_center]" src="/yashi-editorial.jpg" alt="Close detail of a beauty editorial portrait" /></figure>
              <div className="col-span-2 flex min-h-[145px] flex-col justify-center bg-[#532d3a] px-6 py-7 text-[#fff7f1] sm:px-9"><p className="eyebrow text-[#d5bd83]">YOUR NEXT CHAPTER</p><p className="serif mt-3 text-[26px] italic">Come as you are. Leave feeling lovely.</p><a className="mt-4 inline-flex items-center gap-2 text-[10px] font-semibold tracking-[.16em]" href="#appointment">MAKE A PLAN <ArrowRight size={13} /></a></div>
            </div>
          </div>
        </section>

        <section id="appointment" className="bg-[#fbf8f5] px-5 py-20 sm:px-10 md:py-28">
          <div className="mx-auto grid max-w-[1180px] gap-12 lg:grid-cols-[.76fr_1.24fr] lg:gap-20">
            <div className="pt-2">
              <p className="eyebrow mb-5">LET'S MAKE A LITTLE TIME FOR YOU</p>
              <h2 className="serif text-[clamp(2.8rem,5vw,4.8rem)] leading-[1.02] tracking-[-.04em] text-[#382a30]">Your visit<br /><em className="text-[#9a6978]">starts here.</em></h2>
              <p className="mt-6 max-w-[370px] text-[13px] leading-7 text-[#75676b]">Share what you’re looking for and your preferred time. Your message will open in your phone’s SMS app.</p>
              <div className="mt-8 flex gap-3 border-l-2 border-[#b79a5b] bg-[#f6eeee] p-4 text-[11px] leading-5 text-[#66585d]"><CalendarDays className="mt-0.5 shrink-0 text-[#8e6a74]" size={17} /><p><strong className="text-[#532d3a]">A note about appointments</strong><br />This sends an enquiry by SMS—it does not confirm or book an appointment. Please send the message to the salon and wait for a reply.</p></div>
              <a href="tel:09329693991" className="mt-7 inline-flex items-center gap-3 text-sm font-semibold text-[#532d3a]"><Phone size={17} /> 09329693991</a>
            </div>
            <form onSubmit={submitBooking} className="grid gap-x-5 gap-y-5 border border-[#e6d9d9] bg-[#fffdfa] p-5 shadow-[0_16px_55px_rgba(72,45,54,.05)] sm:grid-cols-2 sm:p-8">
              <label className="text-[10px] font-bold tracking-[.12em] text-[#69595f]">NAME <span className="text-[#9a6978]">*</span><input className="field mt-2 text-sm font-normal tracking-normal" type="text" name="name" placeholder="Your name" autoComplete="name" required /></label>
              <label className="text-[10px] font-bold tracking-[.12em] text-[#69595f]">PHONE NUMBER <span className="text-[#9a6978]">*</span><input className="field mt-2 text-sm font-normal tracking-normal" type="tel" name="phone" placeholder="Your number" autoComplete="tel" required /></label>
              <label className="text-[10px] font-bold tracking-[.12em] text-[#69595f]">SERVICE <span className="text-[#9a6978]">*</span><span className="relative mt-2 block"><select className="field appearance-none text-sm font-normal tracking-normal" name="service" value={selectedService} onChange={e => setSelectedService(e.target.value)} required><option value="" disabled>Select a service</option>{services.map(s => <option key={s} value={s}>{s}</option>)}</select><ChevronDown className="pointer-events-none absolute right-3 top-3.5 text-[#806c72]" size={15} /></span></label>
              <label className="text-[10px] font-bold tracking-[.12em] text-[#69595f]">PREFERRED DATE<input className="field mt-2 text-sm font-normal tracking-normal" type="date" name="date" /></label>
              <label className="text-[10px] font-bold tracking-[.12em] text-[#69595f]">PREFERRED TIME<input className="field mt-2 text-sm font-normal tracking-normal" type="time" name="time" /></label>
              <label className="text-[10px] font-bold tracking-[.12em] text-[#69595f] sm:col-span-2">MESSAGE<textarea className="field mt-2 min-h-[98px] resize-y text-sm font-normal tracking-normal" name="message" placeholder="Anything you'd like us to know?" rows={3} /></label>
              <div className="sm:col-span-2">
                <button type="submit" className="btn-primary inline-flex w-full items-center justify-center gap-3 px-6 py-4 text-[10px] font-bold tracking-[.17em] sm:w-auto">CONTINUE TO SMS <ArrowRight size={15} /></button>
                {smsReady && <p role="status" className="mt-3 text-xs leading-5 text-[#532d3a]">Your SMS app should open with your details. Please send the message to enquire; your appointment is not confirmed yet.</p>}
              </div>
            </form>
          </div>
        </section>

        <section id="contact" className="bg-[#f2e6e7] px-5 py-20 sm:px-10 md:py-24">
          <div className="mx-auto grid max-w-[1180px] gap-10 md:grid-cols-[.9fr_1.1fr] md:items-center">
            <div>
              <p className="eyebrow mb-4">FIND YOUR WAY TO US</p><h2 className="serif text-[clamp(2.8rem,5vw,4.4rem)] leading-[1.03] tracking-[-.04em] text-[#382a30]">A little lovely,<br /><em className="text-[#9a6978]">close to home.</em></h2>
              <div className="mt-8 flex gap-4"><MapPin className="mt-1 shrink-0 text-[#9a6978]" size={20} /><div><p className="text-sm font-semibold text-[#46373d]">YASHI'S The Beauty Salon</p><address className="mt-2 max-w-[380px] text-[13px] not-italic leading-6 text-[#75676b]">{address}</address></div></div>
              <div className="mt-7 flex flex-wrap gap-3">
                <a href={mapUrl} target="_blank" rel="noreferrer" className="btn-outline inline-flex items-center gap-3 px-5 py-3.5 text-[10px] font-bold tracking-[.15em]">GET DIRECTIONS <ArrowUpRight size={14} /></a>
                <a href="tel:09329693991" className="btn-primary inline-flex items-center gap-3 px-5 py-3.5 text-[10px] font-bold tracking-[.15em]"><Phone size={14} /> CALL NOW</a>
                <a href="#appointment" className="btn-primary inline-flex items-center gap-3 px-5 py-3.5 text-[10px] font-bold tracking-[.15em]">BOOK APPOINTMENT <ArrowRight size={14} /></a>
              </div>
            </div>
            <a href={mapUrl} target="_blank" rel="noreferrer" aria-label={`Open Google Maps directions to ${address}`} className="group relative flex min-h-[300px] items-center justify-center overflow-hidden border border-[#ddc9c8] bg-[#e9d9d6] md:min-h-[390px]">
              <div className="absolute inset-0 opacity-60" style={{backgroundImage:'linear-gradient(30deg,transparent 48%,#fff8f0 49%,#fff8f0 50%,transparent 51%),linear-gradient(120deg,transparent 47%,#d4bfc0 48%,#d4bfc0 49%,transparent 50%),linear-gradient(0deg,transparent 74%,#f8f0e9 75%,#f8f0e9 76%,transparent 77%)',backgroundSize:'130px 100px,170px 130px,100% 100%'}} />
              <span className="absolute left-[52%] top-[41%] flex h-14 w-14 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border border-[#fff8f1] bg-[#532d3a] text-white shadow-xl transition-transform group-hover:scale-110"><MapPin size={23} /></span>
              <span className="relative mt-28 bg-[#fbf8f5] px-4 py-3 text-center shadow-md"><span className="serif block text-base text-[#532d3a]">YASHI'S The Beauty Salon</span><span className="mt-1 block text-[9px] tracking-[.16em] text-[#78686d]">LALGHATI · BHOPAL</span></span>
              <span className="absolute bottom-4 right-4 flex items-center gap-2 bg-[#fbf8f5] px-3 py-2 text-[9px] font-bold tracking-widest text-[#532d3a]">OPEN IN MAPS <ArrowUpRight size={12} /></span>
            </a>
          </div>
        </section>
      </main>
      <footer className="bg-[#2e2228] px-5 py-12 text-[#f9f1ec] sm:px-10">
        <div className="mx-auto max-w-[1320px]">
          <div className="grid gap-10 border-b border-[#68565d] pb-10 md:grid-cols-[1.3fr_.7fr_.9fr]">
            <div><a href="#home" className="inline-flex items-center gap-3"><span className="flex h-11 w-11 items-center justify-center rounded-full border border-[#b79a5b]"><span className="serif text-xl italic">Y</span></span><span><span className="serif block text-lg">YASHI'S</span><span className="text-[8px] tracking-[.23em] text-[#d0b873]">THE BEAUTY SALON</span></span></a><p className="mt-5 max-w-[340px] text-[12px] leading-6 text-[#cbbec0]">Beauty, Style & Confidence — All in One Place</p></div>
            <div><p className="eyebrow text-[#d0b873]">EXPLORE</p><div className="mt-4 grid gap-3">{nav.map(([l,h]) => <a key={l} href={h} className="w-fit text-xs text-[#e4d7d6] hover:text-white">{l}</a>)}</div></div>
            <div><p className="eyebrow text-[#d0b873]">COME SAY HELLO</p><a href="tel:09329693991" className="mt-4 flex items-center gap-2 text-sm"><Phone size={14} />09329693991</a><a href={mapUrl} target="_blank" rel="noreferrer" className="mt-3 flex max-w-[300px] items-start gap-2 text-xs leading-5 text-[#d4c6c5]"><MapPin size={14} className="mt-1 shrink-0" />{address}</a></div>
          </div>
          <div className="flex flex-col justify-between gap-3 pt-6 text-[9px] tracking-[.08em] text-[#bbaeb1] sm:flex-row"><span>© {new Date().getFullYear()} YASHI'S THE BEAUTY SALON · BHOPAL</span><a href="#home" className="inline-flex items-center gap-2 hover:text-white">BACK TO TOP <ArrowDown className="rotate-180" size={12} /></a></div>
        </div>
      </footer>
      <a href="tel:09329693991" aria-label="Call YASHI's The Beauty Salon" className="fixed bottom-4 right-4 z-40 flex h-14 w-14 items-center justify-center rounded-full bg-[#532d3a] text-white shadow-xl ring-4 ring-[#fbf8f5]/80 transition-transform hover:scale-105 md:hidden"><Phone size={20} /></a>
    </div>
  );
}

function Router() {
  return (
    // Keep a shared shell (sidebar, navbar) outside the boundary so it
    // survives a page crash.
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
